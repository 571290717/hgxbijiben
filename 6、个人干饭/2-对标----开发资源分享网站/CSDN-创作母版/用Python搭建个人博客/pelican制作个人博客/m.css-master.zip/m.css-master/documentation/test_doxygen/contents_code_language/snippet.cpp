/** [0] */
void foo() { return; }
/** [0] */

/** [1] */
#include <cmath>

void bar() { return; }
/** [1] */
