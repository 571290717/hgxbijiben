/** @file
 * @brief Second file
 */

namespace Spread {

/** @brief A templated variable */
template<class T> constexpr const T* Var = nullptr;

}
