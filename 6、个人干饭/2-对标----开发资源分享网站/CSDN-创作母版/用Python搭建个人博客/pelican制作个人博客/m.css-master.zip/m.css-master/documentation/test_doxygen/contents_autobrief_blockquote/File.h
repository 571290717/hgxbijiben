/// @file
/// A file

///> An enum on the right
enum Enum {
    Value ///< A value on the right
};

/* ... where > actually isn't interpreted as "documentation for what follows"
   but rather a Markdown blockquote */
