/** @brief A namespace */
namespace Foo {

/** @brief An inline nested namespace */
inline namespace Bar {

/** @brief Another inline namespace */
inline namespace Baz {}

}

/** @brief A thing */
struct Thing {};

}
