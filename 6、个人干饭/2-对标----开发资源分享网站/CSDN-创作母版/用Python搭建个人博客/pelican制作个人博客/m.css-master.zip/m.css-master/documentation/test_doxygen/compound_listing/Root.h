/* Intentionally not documented */

namespace Root {}
