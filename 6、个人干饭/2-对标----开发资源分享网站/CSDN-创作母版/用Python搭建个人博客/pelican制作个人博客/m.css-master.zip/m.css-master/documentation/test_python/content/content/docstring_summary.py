"""This module retains summary from the docstring"""
