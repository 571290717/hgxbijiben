"""First module, imported as inspect_recursive.first, with no contents"""

import inspect_recursive

from inspect_recursive import Foo as Bar
