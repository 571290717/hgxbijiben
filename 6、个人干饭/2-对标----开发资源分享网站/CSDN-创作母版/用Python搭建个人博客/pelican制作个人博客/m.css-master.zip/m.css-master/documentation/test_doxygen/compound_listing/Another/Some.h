/** @file
 * @brief Some file
 */

namespace Some {}
