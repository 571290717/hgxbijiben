/** Undocumented file */

/** @brief A var that doesn't appear in the docs because it's in undoc file */
int a;
