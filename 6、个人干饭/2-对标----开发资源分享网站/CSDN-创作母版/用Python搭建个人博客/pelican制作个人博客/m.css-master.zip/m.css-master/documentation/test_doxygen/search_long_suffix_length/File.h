#include <string>
#include <functional>
#include <vector>

/** @file
 * @brief A file
 */

/** @brief One fun function */
bool aVeryLongFunctionName(const std::reference_wrapper<const std::vector<std::string>>& a, const std::reference_wrapper<const std::vector<std::string>>& b, const std::reference_wrapper<const std::vector<std::string>>& c, const std::reference_wrapper<const std::vector<std::string>>& d, const std::reference_wrapper<const std::vector<std::string>>& e, const std::reference_wrapper<const std::vector<std::string>>& f, const std::reference_wrapper<const std::vector<std::string>>& g);
