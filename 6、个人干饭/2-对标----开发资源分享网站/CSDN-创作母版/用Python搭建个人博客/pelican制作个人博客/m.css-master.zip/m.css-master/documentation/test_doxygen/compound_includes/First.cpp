/* This is here only to make Doxygen pick First.cpp over First.h and thus make
   location of the namespace in First.cpp (which is not wanted) */

namespace Contained {}
