class Foo:
    """A class"""
    # https://stackoverflow.com/a/33533514, have to use a string in Py3
    def a_thing(self) -> 'Foo':
        """A method"""
        pass
