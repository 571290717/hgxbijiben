/// **************
///
/// SOME HEAVY LICENSE HEADER WITH SOME HEAVY WORDS
///
/// **************

namespace Namespace {

/// Some normal brief documentation
void foo();

}
