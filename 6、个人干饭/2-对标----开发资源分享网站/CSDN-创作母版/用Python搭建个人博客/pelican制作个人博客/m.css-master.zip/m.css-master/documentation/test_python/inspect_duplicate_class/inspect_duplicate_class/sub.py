"""A submodule."""

class Foo:
    """A class present in two modules."""
    pass
