/** @file
 * @brief A file producing warnings
 */

/**
@brief This produces warnings

#### Markdown heading 4 that's rendered the same as 3

Markdown heading, underlined, is misparsed
##########################################

*/
void bar(int foo);
