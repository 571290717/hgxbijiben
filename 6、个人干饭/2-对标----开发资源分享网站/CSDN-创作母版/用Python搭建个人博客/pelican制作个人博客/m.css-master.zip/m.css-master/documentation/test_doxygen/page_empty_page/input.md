@ingroup bla

[comment]: # (The `ingroup` statement above avoids the generation of an empty page for this file.)
[comment]: # (The actual group we add the file to is irrelevant, nothing is actually added.)
[comment]: # (Doxygen will actually create xml/group__bla_md_input.xml, but we want to avoid)
[comment]: # (creating html/group__bla_md_input.html, and listing `input` on the list of pages.)

@class Foo::Bar

This is the detailed description for class `Foo::Bar``.
We put it in a separate file to not clutter the header file too much.
Because this is a really loooong description!
