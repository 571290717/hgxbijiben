A page
######

:ref-prefix:
    content
    content.EnumWithSummary
:summary: Link to a :ref:`Class` and :ref:`VALUE` from a summary.

Link to an :ref:`Enum` and :ref:`THIRD` from the content.
