#!/bin/bash

if [ -d '/user' ]; then echo "Hello"; fi
false
