/** @file
 * @brief A file
 */

/**
@brief A foo

@xrefitem old "Old stuff" "Just old" Xrefitem, gets merged
@xrefitem old "Old stuff" "Just old" with this one by Doxygen itself.

@see See something
@return Does not return anything.

Text.

> A quote that should not cause assertion about an unclosed section
*/
int foo();
