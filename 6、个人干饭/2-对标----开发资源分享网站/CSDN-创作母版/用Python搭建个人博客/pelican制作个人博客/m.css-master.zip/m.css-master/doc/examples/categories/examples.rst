Examples
########

:image: {static}/static/site.jpg
:badge: Info badge for the `Examples <{category}examples>`_ category provided
    by the `Metadata <{filename}/plugins/metadata.rst>`_ plugin.

Detailed category info provided by the `Metadata <{filename}/plugins/metadata.rst>`_
plugin.
