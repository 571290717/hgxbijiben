![鱼猫鼠标连点器](https://github.com/fukadaeimi/yumaoshubiaodaijiqi/blob/main/yumao.ico)
# 鱼猫鼠标连点器
## 使用python创作一个简单的鼠标连续点击器
### **使用本代码需要以下库：**
time,
threading,
pynput,
tkinter,
注意：本代码只能在Windows环境运行。

#### 代码分析
##### 代码主要由四部分构成：
键盘监听；
鼠标控制；
多线程封装；
图形化界面；
###### 该工具以此为案例进行增改[This site was built using [GitHub Pages](https://pages.github.com/)](https://github.com/Komorebi660/PythonCode/tree/master/MouseClick).

# 免责声明：
### 本代码仅供学习和参考使用，不得用于任何商业用途。
### 作者不对代码的正确性、稳定性或适用性做出任何保证。
### 作者不承担任何因使用本代码而导致的任何直接或间接损失。
### 使用者应该在理解代码的基础上谨慎使用，并自行承担风险。
