<script>
export default {
  // reactive state
  data() {
    return {
      //是否显示编辑窗口
      showEdit:false,
            //编辑数据的表单
      editForm:{
          id:"",
          name:"",
          age:"",
          score:"",
      },
      //是否显示添加窗口
      showAdd:false,
      //添加数据的表单
      addForm:{
          id:"",
          name:"",
          age:"",
          score:"",
      },
      mes:'666',
      count: 0,
      students:[{
            id:1,
            name:"张三",
            age:18,
            score:"及格",
      },{
            id:2,
            name:"张4",
            age:19,
            score:"及格",
            
      },{
            id:3,
            name:"张5",
            age:20,
            score:"及格",
      },{
            id:4,
            name:"张6",
            age:18,
            score:"不及格",
      },
      ]
    }
  },

  // functions that mutate state and trigger updates
  methods: {
    increment() {
      this.count++
    },
    //保持添加的数据到表单
    saveAdd(){
      const new_date = { ...this.addForm }
      this.students.push(new_date)
      alert("添加成功！")
      this.showAdd = false
      //清空添加表单
      this.addForm = {
          id:"",
          name:"",
          age:"",
          score:"",
      }
    },
    //删除数据的方法
    deleteRaw(index){
        //通过索引删除数组中的数据
        this.students.splice(index,1)
    },
    clickEdit(stu){
        //显示编辑框
        this.showEdit = true
        this.editForm = {...stu}

    },
    //保持编辑的数据
    saveEdit(stu){
      const index = this.students.findIndex((item)=>{
          return item.id == this.editForm.id
      })
      this.students[index]={...this.editForm}
   },
  },

  // lifecycle hooks
  mounted() {
    console.log(`The initial count is ${this.count}.`)
  }
}
</script>

<template>
  <button @click="increment">Count is: {{ count }}</button>
  <h1>
  {{ mes }}
  </h1>
  <div>
    <!-- 
      1、将student里面的数据渲染成一个表格
      2、实现表格中添加数据行
      3、实现修改表格中的数据行
      4、实现删除表格中的数据行
     -->
     <table border='1'>
      <!-- 表头-->
        <tr>
          <th>学号</th>
          <th>名字</th>
          <th>年龄</th>
          <th>成绩</th>
          <th>操作</th>
        </tr>
      <!-- 内容-->
        <tr v-for='(stu,index) in students' :key='index'>
          <td>{{stu.id}}</td>
          <td>{{stu.name}}</td>
          <td>{{stu.age}}</td>
      <!-- 条件渲染-->
          <td v-if='stu.score == "及格"' style="color:green;">{{stu.score}}</td>
          <td v-else style="color:red;">{{stu.score}}</td>
          <td>
                <button @click='deleteRaw(index)'>删除</button>
                <button @click='clickEdit(stu)'>编辑</button>
          </td>       
        </tr>

     </table>
     <br>
      <!-- 添加按钮-->
     <button @click='showAdd=true'>添加</button>
      <!-- 添加的输入框-->
    <div classth="add_form" v-show = 'showAdd'> 
        <h3>添加数据 </h3>
        <div>学号:<input type="text" v-model = 'addForm.id'></div>
        <div>名字:<input type="text" v-model = 'addForm.name'></div>
        <div>年龄:<input type="text" v-model = 'addForm.age'></div>
        <div>成绩:<input type="text" v-model = 'addForm.score'></div>
        <div>
           <button @click='showAdd=false'>取消</button>
            <button @click="saveAdd">保存</button>

        </div>
              <!-- 编辑的输入框-->
       </div>       
    <div class="add_form" v-show = 'showEdit'> 
        <h3>添加数据 </h3>
        <div>学号:<input type="text" v-model = 'editForm.id' disabled></div>
        <div>名字:<input type="text" v-model = 'editForm.name'></div>
        <div>年龄:<input type="text" v-model = 'editForm.age'></div>
        <div>成绩:<input type="text" v-model = 'editForm.score'></div>
        <div>
           <button @click='showEdit=false'>取消</button>
            <button @click="saveEdit">保存</button>

        </div>
    </div>
  </div>

</template>

<style scoped>


.add_form{
    width:300px;
    height:300px;
    box-shadow: 0 0 5px #000;
    position:fixed;
    top:calc((100vw - 300px)/2);
    left: calc((100vw - 300px)/2);
    text-align : center;
}
</style>



























