# Python-GUI-Projects
<p align="center">

## Description

All the GUI projects that is built in Python.

## Library Used
`import tkinter`

## How to run
Running the script is really simple! Just open a terminal in the folder where your script is located and run the following command:

## Projects List
`1. Advance Gui Youtube Downloader` <br/>
`2. Dictionary Gui Application` <br/>
`3. Email Sender Gui Application` <br/>
`4. Instagram User detail Gui Application` <br/>
`5. Name Generator Gui Application` <br/>
`6. Notepad Gui Application` <br/>
`7. Paint Gui Application` <br/>
`8. Piano Gui Application` <br/>
`9. Restruant Management System Gui Application` <br/>
`10. Google Translator Gui Application` <br/>
`11. Cafe Management System Gui Application` <br/>
`12. Calculator Gui Application` <br/>
`13. Calculator with Images Gui Application` <br/>
`14. Calender Gui Application` <br/>
`15. Currency Converter Gui Application` <br/>
`16. SMS Sender Gui Application` <br/>
`17. Url Shortener Gui Application` <br/>
`18. Weather Gui Application` <br/>
`19. Basic Gui Youtube Downloader` <br/>
`20. Tic Tac Toe` <br/>



